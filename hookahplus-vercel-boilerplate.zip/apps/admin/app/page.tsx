export default function Page(){ return <main style={{padding:24}}><h1>Hookah+ Admin</h1></main> }
