export default function Page(){ return <main style={{padding:24}}><h1>Hookah+ Dashboard</h1><a href='/fire'>Fire Session Canvas</a></main> }
