'use client'
export default function Fire(){ return <main style={{padding:24}}><h2>Fire Session Canvas</h2><p>Stub - integrate real component later.</p></main> }
