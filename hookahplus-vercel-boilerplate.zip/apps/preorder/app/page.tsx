export default function Page(){ return <main style={{padding:24}}><h1>Hookah+ Preorder</h1></main> }
