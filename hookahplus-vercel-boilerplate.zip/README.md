Hookah+ Vercel Boilerplate — see instructions in chat.
